# Análise da branch `desenvolvimento` — junho/2026

**Data:** 2026-06-09  
**Branch analisada:** `origin/desenvolvimento` (local: `integracao/hibrida`)  
**HEAD:** `19f0070` — *wip fase 7 exportacao PDF report*  
**Merge-base com `feature/back-end-python`:** `d4a3896`  
**Commits desde base:** desenvolvimento **16** | feature **2**

> Complementa o relatório do líder em `analise_impacto_integracao.md`.  
> Objetivo: explicar **por que a integração ainda pode quebrar** mesmo com decisões Fase 0 e estratégia híbrida.

---

## Resumo executivo

A equipe tem razão: o risco não foi eliminado só com reunião Fase 0. Três fatores principais:

1. **`git merge feature/back-end-python` apaga o stack Node** — `server.js`, `package.json`, `pages/`, JS legado são removidos pela feature, não atualizados.
2. **`desenvolvimento` evoluiu** desde a análise original — PDF export, reset senha completo, CPF reforçado; a feature Python não tem paridade.
3. **Decisões Fase 0 incompletas/erradas** — referência a papel `MEDICO` (não existe); faltam idade vs nascimento, enum de triagem, auth storage, estratégia de merge aditiva.

**Estratégia segura:** importação aditiva (`git checkout origin/feature/... -- <paths>`), nunca merge Git padrão nas Fases 1–3.

---

## Estado atual das branches

| Branch | Stack | HEAD | Observação |
|--------|-------|------|------------|
| `desenvolvimento` | Node 3000 + MySQL + `pages/` + `styles/` | `19f0070` | Sistema funcional do grupo |
| `feature/back-end-python` | FastAPI 8000 + PostgreSQL + `paginas/` + `estilos/` | `1322ae5` | MVP Python; substituição total do legado |
| `integracao/hibrida` | Igual `desenvolvimento` hoje | `19f0070` | **Sem `backend/` commitado** ainda |

---

## O que `desenvolvimento` tem e a feature não tem

| Funcionalidade | Node (`desenvolvimento`) | FastAPI (`feature`) | Risco se integrar mal |
|----------------|--------------------------|---------------------|------------------------|
| CPF obrigatório + busca | `paciente.cpf`, `js/pacientes.js` | Patient sem CPF; form usa idade | CRUD quebra no modo FastAPI |
| Data de nascimento | `data_nascimento_paciente` | `age: int` | Migração de dados impossível sem transformação |
| Papel de usuário | `USUARIO` \| `ADMIN` | `PADRAO` \| `ADMIN` | RBAC inconsistente |
| Resultado triagem | `RECOMENDADO` / `NAO_RECOMENDADO` | `ENCAMINHAR_TESTE_GENETICO` / `SEM_ENCAMINHAMENTO_IMEDIATO` | Dashboard/relatórios divergem |
| Auth frontend | `localStorage` | JWT + `sessionStorage` | Sessões incompatíveis entre modos |
| Triagem | Client-side (`nova_avaliacao.html`) | Server-side (`triage.py`) | Scores/fluxos podem divergir |
| Reset senha | 3 rotas + `redefinir_senha.html` + Nodemailer | Stub “fale com admin” | Grupo perde fluxo funcional |
| PDF laudo | `js/resultado.js` (html2pdf + CPF) | Ausente | Perda de exportação |
| PDF consolidado | `js/relatorios.js` (WIP fase 7) | Ausente | Perda de exportação |
| Foto paciente | `foto_paciente` (SQL) | Não no Alembic | Campo perdido |
| Auditoria | Tabela `auditoria` | Ausente no PostgreSQL | Perda de auditoria |

**Nota sobre MEDICO:** não existe enum `MEDICO`. O MySQL usa `USUARIO`. “Medico” em `modificacoes_extras_no_sql.sql` é só nome de usuário de teste.

---

## Arquivos que a feature DELETARIA no merge

Se fizer `git merge origin/feature/back-end-python` em `integracao/hibrida`, o Git tentará remover:

### Backend e dependências Node
- `server.js`
- `package.json`, `package-lock.json`

### Frontend legado
- `pages/` inteiro (16 HTML, incluindo `redefinir_senha.html`, `nova_avaliacao.html`, `resultado.html`)
- `styles/global.css`
- `js/login.js`, `js/dashboard.js`, `js/pacientes.js`, `js/novo_paciente.js`
- `js/nova_avaliacao.js`, `js/resultado.js`, `js/relatorios.js`
- `js/recuperarSenha.js`, `js/redefinirSenha.js`, `js/usuarios.js`
- `js/auth.js`, `js/storage.js`

### SQL e docs do grupo
- `xFragilVersao1.sql`, `xFragilVersao2.sql`, `x_fragil_salvarImagem.sql`
- `migrations/001_add_password_reset_to_usuario.sql`
- `backup_*.sql`, `implementation_plan.md`, etc.

**Um merge aceito sem rejeitar cada deleção = sistema do grupo morto.**

---

## O que a feature ADICIONA (importação segura)

Paths a trazer com `git checkout origin/feature/back-end-python -- <path>`:

```
backend/
paginas/
estilos/
js/configuracao.js
js/api.js
js/armazenamento.js
js/autenticacao.js
js/menu.js
js/sintomas.js
js/utilidades.js
js/paginas/
index.html          # cuidado: não sobrescrever entry do grupo sem toggle
.gitignore
```

**Não trazer** remoções dos paths listados na seção anterior.

---

## Páginas só no legado (sem equivalente em `paginas/`)

| Arquivo | Função |
|---------|--------|
| `pages/Secundarias/nova_avaliacao.html` | Fluxo triagem client-side |
| `pages/Secundarias/resultado.html` | Laudo + PDF individual |
| `pages/cadastro/redefinir_senha.html` | Conclusão reset senha |
| `pages/Principais/usuarios.html` | Gestão usuários (feature usa `paginas/admin/`) |

Até Fase 4, o grupo deve continuar em `pages/` com `MODO_API = 'node'`.

---

## Matriz de risco — por que ainda quebra

| # | Cenário de quebra | Probabilidade | Mitigação |
|---|-------------------|---------------|-----------|
| R1 | Merge Git aceita deleção de `server.js` | Alta se merge padrão | Importação aditiva; proibir merge Fases 1–3 |
| R2 | `pages/` removida no merge | Alta | Cherry-pick só paths aditivos |
| R3 | Toggle FastAPI antes de paridade CPF | Média | `MODO_API` default `'node'` até Fase 3d |
| R4 | Mapear MEDICO em vez de USUARIO | Média | Corrigir decisões Fase 0 |
| R5 | Perda PDF client-side | Alta se trocar frontend cedo | Manter `pages/` + `js/relatorios.js` até port |
| R6 | Reset senha perdido | Alta | Manter rotas Node até port FastAPI |
| R7 | Dados MySQL importados sem transformação idade/nascimento | Alta | Script migração com regras explícitas |
| R8 | Enum triagem diferente nos relatórios | Média | Adapter Fase 3c |
| R9 | `localStorage` vs `sessionStorage` misturados | Média | Modos separados por pasta até Fase 4 |
| R10 | Triagem client vs server com scores diferentes | Média | Testes comparativos Fase 3c |
| R11 | `index.html` raiz sobrescrito | Média | Redirect condicional ou manter `pages/index.html` principal |
| R12 | `backend/` ausente em `integracao/hibrida` | Certa hoje | Fase 1 traz backend sem tocar Node |

---

## Mensagem para apresentar à equipe (1 slide)

> O plano híbrido **funciona** se importarmos o código Python **sem apagar** o Node.  
> O que **quebra** é tratar a branch Python como atualização incremental — ela foi feita como **substituição total**.  
> Até portarmos CPF, PDF, reset senha e alinhar papéis (`USUARIO`/`PADRAO`), o grupo continua em `pages/` + `npm start`.

---

## Referências

- Relatório original: `analise_impacto_integracao.md`
- Plano atualizado: `plano_integracao_hibrida.md`
- Decisões equipe: `decisoes_fase0.md`
- Schema MySQL: `xFragilVersao2.sql`

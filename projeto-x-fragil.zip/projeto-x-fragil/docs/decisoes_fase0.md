# Decisões Fase 0 — Integração híbrida

**Preencher com a equipe antes da Fase 1.** Reunião sugerida: 20 minutos.

Data da reunião: _______________  
Participantes: _______________

> **Atualizado:** corrige erro MEDICO (não existe no schema). Enum real: `USUARIO` | `ADMIN`.

---

## 1. Campo CPF no backend Python

| Opção | Descrição |
|-------|-----------|
| A | Reintroduzir CPF no schema PostgreSQL (recomendado) |
| B | Manter só nome + idade (não recomendado — quebra paridade) |
| C | Bridge: CPF só no Node até Fase 4 |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 2. Papel USUARIO (MySQL) vs PADRAO (FastAPI)

> **Não existe `MEDICO` no banco.** O enum é `USUARIO` | `ADMIN`. "Medico" é só nome de usuário de teste.

| Opção | Descrição |
|-------|-----------|
| A | Mapear `USUARIO` → `PADRAO` no login (recomendado) |
| B | Renomear enum Python para `USUARIO` |
| C | Suportar ambos no JWT |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 3. Recuperação de senha

| Opção | Descrição |
|-------|-----------|
| A | Manter fluxo Node (Nodemailer + `redefinir_senha.html`) até portar |
| B | Implementar no FastAPI na Fase 3e |
| C | Aceitar ausência — “falar com administrador” |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 4. Exportação PDF de relatórios

> PDF no Node é **client-side** (html2pdf), não endpoint de API.

| Opção | Descrição |
|-------|-----------|
| A | Manter PDF em `pages/` + `js/relatorios.js` / `resultado.js` até portar |
| B | Implementar no FastAPI na Fase 3e |
| C | Adiar — só JSON no MVP integrado |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 5. Estrutura de pastas (pages/ vs paginas/)

| Opção | Descrição |
|-------|-----------|
| A | Conviver ambas Fase 2–3; grupo usa `pages/`; unificar na Fase 4 (recomendado) |
| B | Migrar tudo para `paginas/` imediatamente |
| C | Manter `pages/` como principal até Fase 4 |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 6. Banco de dados em desenvolvimento

| Opção | Descrição |
|-------|-----------|
| A | PostgreSQL para FastAPI; MySQL mantido para Node (híbrido) |
| B | Migrar tudo para PostgreSQL de uma vez |
| C | Adiar FastAPI em dev — só Node por enquanto |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 7. Idade vs data de nascimento

| Opção | Descrição |
|-------|-----------|
| A | Adicionar `birth_date` no Python; calcular idade na UI (recomendado) |
| B | Manter só `age` no Python; perder data de nascimento na migração |
| C | Manter ambos campos no PostgreSQL |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 8. Enum de resultado de triagem

Node: `RECOMENDADO` / `NAO_RECOMENDADO`  
FastAPI: `ENCAMINHAR_TESTE_GENETICO` / `SEM_ENCAMINHAMENTO_IMEDIATO`

| Opção | Descrição |
|-------|-----------|
| A | Adapter na migração e na API (recomendado) |
| B | Alterar enum Python para igualar MySQL |
| C | Aceitar divergência nos relatórios até Fase 4 |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 9. Armazenamento de sessão (auth frontend)

| Opção | Descrição |
|-------|-----------|
| A | `localStorage` em `pages/` (Node); `sessionStorage` em `paginas/` (FastAPI) — separados (recomendado) |
| B | Migrar tudo para `sessionStorage` + JWT já na Fase 2 |
| C | Manter `localStorage` em ambos |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 10. Triagem: client-side vs server-side

| Opção | Descrição |
|-------|-----------|
| A | Manter triagem client em `pages/nova_avaliacao.html`; server em FastAPI; alinhar scores na Fase 3c |
| B | Forçar triagem server-side já na Fase 2 |
| C | Manter só client-side até Fase 4 |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 11. Estratégia de integração Git

| Opção | Descrição |
|-------|-----------|
| A | Importação aditiva (`git checkout feature -- <paths>`); **proibir merge** Fases 1–3 (recomendado) |
| B | Merge Git resolvendo conflitos manualmente |
| C | Copiar arquivos à mão sem Git |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## 12. Pasta principal para o grupo até Fase 4

| Opção | Descrição |
|-------|-----------|
| A | `pages/` + `npm start` — `MODO_API` default `'node'` (recomendado) |
| B | `paginas/` + FastAPI como default |
| C | Duas URLs separadas documentadas no README |

**Decisão da equipe:** [ ] A  [ ] B  [ ] C  
**Responsável:** _______________

---

## Defaults (se equipe não decidir na reunião)

- CPF: **A**
- USUARIO/PADRAO: **A** (não MEDICO)
- Reset senha: **A**
- PDF: **A**
- Pastas: **A**
- Banco: **A**
- Idade/nascimento: **A**
- Enum triagem: **A**
- Auth storage: **A**
- Triagem: **A**
- Estratégia Git: **A**
- Pasta principal: **A**

**Aprovado por:** _______________  **Data:** _______________

---

## Registro de exceções — Fase 1

### E1 — Migrations 0001/0002 alteradas na importação (exceção à Regra 2)

A Regra 2 diz "não alterar 0001/0002". Na Fase 1, ambas apareceram como modificadas porque as versões importadas da `feature/back-end-python` **não rodam em PostgreSQL** como vieram:

- `0001_initial_schema.py`: `sa.Enum(...).create()` + reuso dos enums em `create_table` emitia `CREATE TYPE` duas vezes → erro `DuplicateObject`. Corrigido para `PgENUM(..., create_type=False)` + blocos idempotentes `DO $$ ... EXCEPTION WHEN duplicate_object`.
- `0002_seed_symptoms_and_default_admin.py`: revision id tem 36 chars, mas `alembic_version.version_num` é `VARCHAR(32)` → stamp falha. Corrigido com `ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(64)`.

**Decisão:** exceção **aceita e documentada**. Correções são mínimas, de compatibilidade, sem alterar dados nem a semântica do schema, e necessárias para atingir o critério de aceite da Fase 1 (`alembic upgrade head` cria o schema). Reverter quebraria o aceite e ainda exigiria tocar a `0001`.

> Nota: `triage.py` também aparece modificada, mas é adição pura (properties `score`/`threshold_used`/`result` + alias `calculate_triage`) que corrige inconsistência da própria feature (os testes importados já usavam esses nomes). `pytest` rodado: 4 passed (cumpre Regra 2).

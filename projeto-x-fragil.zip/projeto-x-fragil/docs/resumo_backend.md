# Resumo do Projeto (MVP Síndrome do X Frágil)

## O que o sistema faz

Sistema de apoio à triagem clínica: cadastro de pacientes, checklist com 12 sintomas,
cálculo de score e indicação de encaminhamento para teste genético.

---

## Backend (API)

### Implementado
- API REST em FastAPI (documentação em /docs).
- PostgreSQL com migrações Alembic.
- Login com JWT e perfis ADMIN / PADRAO.
- CRUD de pacientes, avaliações com triagem validada, relatórios e painel.
- Testes de cálculo e permissões (RBAC).

### Decisões técnicas
- Sexo M/F apenas (pesos e limiares validados: M 0,56 / F 0,55).
- Macroorquidismo com peso 0 no feminino.
- Admin padrão: admin@clinica.com / Admin@123

---

## Frontend (interface)

### Mudanças realizadas
- Pastas antigas pages/ e styles/ substituídas por paginas/, estilos/ e js/.
- Nomes em português (snake_case): painel.html, hub_admin.html, etc.
- Login real via API (JWT em sessionStorage, não localStorage).
- Menu lateral único em js/menu.js (sem repetir HTML em cada página).
- Telas conectadas à API:
  - Painel: estatísticas do dashboard
  - Pacientes: listar e cadastrar
  - Avaliações: checklist 12 sintomas e resultado da triagem
  - Relatórios: filtros e tabela de avaliações
  - Admin: usuários e edição de pacientes
- Formulários alinhados ao backend (idade, sexo M/F, sem CPF).
- CSS reorganizado, HTML corrigido, interface em português.

### Como rodar
- Backend: cd backend && uvicorn app.main:app --reload --port 8000
- Frontend: python -m http.server 5500 (na raiz do projeto)
- Acesso: http://localhost:5500/paginas/cadastro/login.html

---

## O que ainda falta

| Item | Situação |
|------|----------|
| Recuperação de senha | Tela existe; backend sem envio de email |
| Exportar relatórios CSV/PDF | Botão avisa que não está disponível |
| PDF imprimível por avaliação | Só window.print() do navegador |
| Lista de sintomas dinâmica | Fixa em js/sintomas.js (igual ao seed do banco) |
| HTTPS em produção | Recomendado para JWT em ambiente real |
